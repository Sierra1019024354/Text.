package cuaderno;


public class Cuaderno {


    public static void main(String[] args) {
        
        
        Cuadernos Mycuaderno = new Cuadriculado();
        
        

        Mycuaderno.Cuadernos();
        Mycuaderno.Rayado();
    }
    
}
