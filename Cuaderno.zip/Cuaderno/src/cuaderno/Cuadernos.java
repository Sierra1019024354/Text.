
package cuaderno;

public  interface  Cuadernos {

    public void Rayado();
    public void Cuadernos();
    
   }
