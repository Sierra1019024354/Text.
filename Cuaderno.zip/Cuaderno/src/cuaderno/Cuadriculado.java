
package cuaderno;

public class Cuadriculado implements Cuadernos  {

    @Override
    public void Rayado() {
       System.out.println("este cuaderno es rayado");
    }

    @Override
    public void Cuadernos() {
       System.out.println("este cuaderno es cuadriculado");
    }


}
