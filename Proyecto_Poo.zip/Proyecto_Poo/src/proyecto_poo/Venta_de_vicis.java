package proyecto_poo;


public class Venta_de_vicis {

    

    public static void main(String[] args) {
              
        Precios Mypresio = new Precios();
        BiciMontaña MyBiciMontaña = new BiciMontaña ();
        BiciPlegable MyBiciPlegable = new BiciPlegable();
        Descrip descripcion = new Descrip();
        BiciHibrida MyBiciHibrida = new BiciHibrida();
        
        MyBiciMontaña.TiposBicicletas();
        Mypresio.mostrarPrecio();
        MyBiciMontaña.TiposBicicleta();
        descripcion.MontañaDE();
        MyBiciPlegable.TiposBicicleta();
        Mypresio.mostrarPrecio(0);
        descripcion.PlegableDE();
        MyBiciHibrida.TiposBicicleta();
        Mypresio.mostrarprecio(0);
        descripcion.Hibrida();
    }
         
}
