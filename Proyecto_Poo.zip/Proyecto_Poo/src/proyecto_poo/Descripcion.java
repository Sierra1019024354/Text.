package proyecto_poo;


public interface Descripcion {
    
    public void MontañaDE();
    public void PlegableDE();
    public void Hibrida();
}
