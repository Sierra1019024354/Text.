package proyecto_poo;


public class BiciMontaña extends Bicicletas {

    @Override
    public void TiposBicicleta() {
        System.out.println("Montañera  ");
    }
    
    
}
