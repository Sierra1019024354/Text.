
package proyecto_poo;


public class BiciPlegable extends Bicicletas {
    
    
    

    @Override
    public void TiposBicicleta() {
      System.out.println("Plegable  ");   
    }
}
