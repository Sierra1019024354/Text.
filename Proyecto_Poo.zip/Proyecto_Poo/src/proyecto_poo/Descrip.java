package proyecto_poo;


public class Descrip implements Descripcion {

    @Override
    public void MontañaDE() {
        System.out.println("es un tipo de bicicleta diseñada para terrenos irregulares y desafiantes, como senderos, montañas y caminos sin pavimentar");
    }

    @Override
    public void PlegableDE() {
        System.out.println("es un tipo de bicicleta diseñada para reducir su tamaño a través de bisagras o mecanismos de plegado");
    }

    @Override
    public void Hibrida() {
        System.out.println("es un tipo de bicicleta diseñada para ser versátil y adaptarse a diferentes tipos de terreno, combinando características de bicicletas de montaña y de carretera"); 
    }
    
}
