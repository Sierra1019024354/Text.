package proyecto_poo;

public class Precios {
    
    private double precioMontaña = 300_000.00; 
    private double precioPlegable = 500_000.00; 
    private double precioHibrida = 400_000.00;
  
    public Precios() {
       
    }

    public void mostrarPrecio() {
        System.out.println("El valor de tu bicicleta montañera es: $" + precioMontaña);
    }

    public void mostrarPrecio(double cantidadPlegable) {
        double precioP = precioPlegable;
        System.out.println("El valor total para " +" bicicleta plegable es: $" + precioP );
    }
    public void mostrarprecio(int cantidadHibrida){
        int precioH = (int) precioHibrida;
        System.out.println("el valor total para la bicicleta hibrida es"+precioH);
    }
}