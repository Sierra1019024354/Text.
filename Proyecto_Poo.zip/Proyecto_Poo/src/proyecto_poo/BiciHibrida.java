
package proyecto_poo;


public class BiciHibrida extends Bicicletas {

    @Override
    public void TiposBicicleta() {
   
        System.out.println("Hibrida");    }
    
}
