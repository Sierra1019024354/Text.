package proyecto_poo;


public abstract class Bicicletas {
    
   public abstract void TiposBicicleta();
   
   public void TiposBicicletas(){
      System.out.println("Bicicletas En Venta"); 
      
   }
}
